import os
import torch
import pandas as pd
import torch.nn as nn
from PIL import Image
import torchvision.transforms as transforms


class OCTDataset(torch.utils.data.Dataset):
    
    def __init__(self, img_dir, label_dir):

        self.img_dir = img_dir
        self.label_dir = label_dir
        self.cache = {}
        self.valid_indices = []
        self.transform = self.get_transform()

        for i in range(30, 314):
            label_fname_x = f'Intensity.tif{i}_x.xlsx'
            x_path = os.path.join(self.label_dir, label_fname_x)
            if os.path.exists(x_path) is True:
                self.valid_indices.append(i)

    def __len__(self):
        return len(self.valid_indices)

    def __getitem__(self, idx):

        idx = self.valid_indices[idx]

        if idx in self.cache:
            return self.cache[idx]

        img_fname = f'image_{idx}.tif'
        img_path = os.path.join(self.img_dir, img_fname)

        with Image.open(img_path) as img:
            img_tensor = self.transform(img)

        label_fname_x = f'Intensity.tif{idx}_x.xlsx'
        label_fname_y = f'Intensity.tif{idx}_y.xlsx'

        x_path = os.path.join(self.label_dir, label_fname_x)
        y_path = os.path.join(self.label_dir, label_fname_y)

        df_x = pd.read_excel(x_path, header=None).values
        df_y = pd.read_excel(y_path, header=None).values

        x = torch.tensor(df_x, dtype=torch.float32).unsqueeze(-1)
        y = torch.tensor(df_y, dtype=torch.float32).unsqueeze(-1)

        xy = torch.cat((x, y), dim=-1).view(-1)

        result = {
            "image": img_tensor,
            "label": xy
        }
        self.cache[idx] = result

        return result

    def get_transform(self):
        transform = transforms.Compose([
            transforms.PILToTensor(),
            transforms.ConvertImageDtype(torch.float32),
            transforms.Normalize(mean=[0.5], std=[0.5])
        ])
        return transform


class Net(nn.Module):

    def __init__(self):

        super().__init__()

        self.conv_layers = nn.Sequential(
            nn.Conv2d(1, 1, (10, 4), stride=4, groups=1),
            nn.BatchNorm2d(1),
            nn.ReLU(),
            nn.MaxPool2d((5, 5), 5),
            nn.Conv2d(1, 16, kernel_size=1),
            nn.BatchNorm2d(16),
            nn.ReLU(),
            nn.MaxPool2d((5, 5), 5),
        )

        self.gap = nn.AdaptiveAvgPool2d(1)
        self.flatten = nn.Flatten()

        self.linear_layers = nn.Sequential(
            nn.Linear(16, 16),
            nn.ReLU(),
            nn.Linear(16, 1600)
        )

    def forward(self, x):
        out = self.linear_layers(self.flatten(self.gap(self.conv_layers(x))))
        return out
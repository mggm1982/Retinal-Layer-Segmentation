import torch
from classes import OCTDataset, Net
from torch.utils.tensorboard import SummaryWriter


#torch.manual_seed(0)

def smooth_loss(x):
    x_split = x.view(x.shape[0], 8, -1)
    return ((x_split[:, :, :-2] - x_split[:, :, 2:]) ** 2).sum() / x.shape[0]

def loss_fn(prediction, ground_truth, smooth_coeff=0.01):
    return torch.nn.functional.mse_loss(prediction, ground_truth) + smooth_coeff * smooth_loss(prediction)

def train_one_epoch(model, optimizer, tb_writer, train_loader, epoch_idx):

    running_loss = 0.0

    for i, batch in enumerate(train_loader):

        optimizer.zero_grad()
        predicted = model(batch["image"])
        loss = loss_fn(predicted, batch["label"])
        loss.backward()
        optimizer.step()

        running_loss += loss.item()

        print(f"    Batch {i + 1}: loss {loss.item()}")
        tb_x = epoch_idx * len(train_loader) + i + 1
        tb_writer.add_scalar("Loss/train", loss.item(), tb_x)
    
    num_batches = len(train_loader)
    avg_loss = running_loss / num_batches

    return avg_loss 


def main():

    dataset = OCTDataset("Images", "XFiles")

    dataset_size = len(dataset)
    train_size = int(0.8 * dataset_size)
    val_size = dataset_size - train_size

    train_set, val_set = torch.utils.data.random_split(dataset, [train_size, val_size])

    params = {
        "batch_size": 32,
        "shuffle": True,
        "num_workers": 2 
    }

    train_loader = torch.utils.data.DataLoader(train_set, **params)
    val_loader = torch.utils.data.DataLoader(val_set, **params)

    writer = SummaryWriter("Results")

    model = Net()
    print("Number of parameters:", sum(param.numel() for param in model.parameters()))

    optimizer = torch.optim.Adam(model.parameters())

    EPOCHS = 200 

    best_vloss = 1e6

    # TRAINING LOOP -----------------------------------

    for epoch in range(EPOCHS):

        print(f"Epoch: {epoch + 1}")

        model.train()

        avg_loss = train_one_epoch(model, optimizer, writer, train_loader, epoch)

        model.eval()

        running_vloss = 0.0

        with torch.no_grad():
            for _, vbatch in enumerate(val_loader):
                vpredicted = model(vbatch["image"])
                vloss = loss_fn(vpredicted, vbatch["label"])
                running_vloss += vloss.item()

        num_batches = len(val_loader)
        avg_vloss = running_vloss / num_batches

        print(f"LOSS: train {avg_loss}, valid {avg_vloss}")

        writer.add_scalars(
            "Training vs. Validation Loss",
            {"Training": avg_loss, "Validation": avg_vloss},
            epoch + 1
        )
        writer.flush()

        if avg_vloss < best_vloss:
            best_vloss = avg_vloss
            model_path = f'Models3\octmodel_{epoch + 1}'
            torch.save(model.state_dict(), model_path)

    # -------------------------------------------------


if __name__ == "__main__":
    main()
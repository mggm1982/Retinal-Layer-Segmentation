import sys
import torch
from PIL import Image
from classes import Net
import matplotlib.pyplot as plt
from torchvision import transforms


img_no = int(sys.argv[1])

model = Net()
#model.load_state_dict(torch.load('Models\octmodel_139', weights_only=True))
model.load_state_dict(torch.load('Models2\octmodel_195', weights_only=True))
model.eval()

transform = transforms.Compose([
    transforms.PILToTensor(),
    transforms.ConvertImageDtype(torch.float32),
    transforms.Normalize(mean=[0.5], std=[0.5])
])

img_path = f'Images\image_{img_no}.tif'

with Image.open(img_path) as img:
    img_tensor = transform(img)

with torch.no_grad():
    out = model(img_tensor.unsqueeze(0))

pred_xy = out.view(8, -1)
x = pred_xy[:, ::2].numpy()
y = pred_xy[:, 1::2].numpy()

img = plt.imread(img_path)
plt.imshow(img, cmap='grey')

plt.scatter(x, y, s=1)
plt.show()
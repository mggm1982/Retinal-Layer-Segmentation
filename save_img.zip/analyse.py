import os
import numpy as np
from PIL import Image

for i in range(339):

    img_no = i + 1
    fname = f'Images\image_{img_no}.tif'

    if os.path.exists(fname) is False:
       continue 

    with Image.open(fname) as img:
        img = np.array(img)
        if img.shape != (806, 500):
            print(img_no)
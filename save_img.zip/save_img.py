import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

for i in range(29, 321):

    fname = f'XFiles\Intensity.tif{i}_x.xlsx'
    
    if os.path.exists(fname) is False:
       continue 

    img = plt.imread(f'Images\image_{i}.tif')
    plt.imshow(img, cmap='grey')

    df_x = pd.read_excel(f'XFiles\Intensity.tif{i}_x.xlsx', header=None)
    df_y = pd.read_excel(f'XFiles\Intensity.tif{i}_y.xlsx', header=None)

    x = np.array(df_x)
    y = np.array(df_y)

    plt.scatter(x, y, s=1)

    plt.savefig(f'Saved\image_{i}')
    plt.close()
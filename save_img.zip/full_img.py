import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

img_no = int(sys.argv[1])

img = plt.imread(f'Images\image_{img_no}.tif')
plt.imshow(img, cmap='grey')

df_x = pd.read_excel(f'XFiles\Intensity.tif{img_no}_x.xlsx', header=None)
df_y = pd.read_excel(f'XFiles\Intensity.tif{img_no}_y.xlsx', header=None)

x = np.array(df_x)
y = np.array(df_y)

plt.scatter(x, y, s=1)
plt.show()